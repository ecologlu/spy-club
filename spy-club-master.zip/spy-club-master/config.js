module.exports = {
  awsAccesskeyID: "AKIAIO47LPB2AHBT7N4Q",
  awsSecretAccessKey: "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",
  awsRegion: "us-east-1"
};
